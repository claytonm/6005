package minesweeper;

public class Board {

}
