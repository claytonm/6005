package echo.server;

import java.io.IOException;

/**
 * A simple server that will echo client inputs.
 */
public class EchoServer {
    	
    /**
     * @param args String array containing Program arguments.  It should only 
     *      contain at most one String indicating the port it should connect to.
     *      The String should be parseable into an int.  
     *      If no arguments, we default to port 4444.
     */
	public static void main(String[] args) throws IOException {
	    //TODO complete this implementation.
    }
}
