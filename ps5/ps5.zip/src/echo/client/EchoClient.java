package echo.client;

import java.io.IOException;

/**
 * A simple client that will interact with an EchoServer.
 */
public class EchoClient {

	/**
	 * @param args String array containing Program arguments.  It should only 
	 *      contain exactly one String indicating which server to connect to.
	 *      We require that this string be in the form hostname:portnumber.
	 */
	public static void main(String[] args) throws IOException {
	    // TODO Complete this implementation. 
	}

}
